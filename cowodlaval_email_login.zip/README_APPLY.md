# CowoDlaVal - Email login update

This overlay changes the public Django login from username/password to email/password
while keeping Django's standard `User` model and the existing username field.

Files replaced:
- `accounts/forms.py`
- `accounts/views.py`
- `accounts/urls.py`

No database migration is required.

## Apply

From the repository root:

```bash
cp -r path/to/cowodlaval_email_login/accounts/* accounts/
docker compose up -d --build
```

Then verify:

```bash
docker compose exec web python manage.py check
```

The public login at `/accounts/login/` now accepts the user's email address.
The remaining standard Django auth routes (logout, password reset, password change)
continue to be provided by `django.contrib.auth.urls`.

The signup form also rejects duplicate email addresses case-insensitively so that
each email can identify only one account.
